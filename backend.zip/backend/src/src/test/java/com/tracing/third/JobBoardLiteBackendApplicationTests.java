package com.tracing.third;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobBoardLiteBackendApplicationTests {

    public static void main(String[] args) {
        SpringApplication.run(JobBoardLiteBackendApplicationTests.class, args);
    }
}
