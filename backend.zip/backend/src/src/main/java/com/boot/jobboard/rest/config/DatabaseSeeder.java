package com.boot.jobboard.rest.config;

import com.boot.jobboard.rest.dvo.Job;
import com.boot.jobboard.rest.repo.JobRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DatabaseSeeder implements CommandLineRunner {

    private final JobRepository jobRepository;

    public DatabaseSeeder(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Override
    public void run(String... args) {
        if (jobRepository.count() == 0) {
            List<Job> jobs = Arrays.asList(
                new Job(null, "AI Prompt Engineer", "Promptly", "San Francisco", 
                        "Design and optimize AI prompts for enterprise-grade language models.", 
                        "115,000 - 140,000", 
                        Arrays.asList("LLMs", "Prompt Engineering", "Python")),

                new Job(null, "Blockchain Developer", "ChainVerse", "Miami", 
                        "Develop and maintain blockchain-based applications.", 
                        "105,000 - 130,000", 
                        Arrays.asList("Solidity", "Ethereum", "Smart Contracts")),

                new Job(null, "Robotics Engineer", "RoboDynamics", "Boston", 
                        "Build autonomous robotic systems for warehouse automation.", 
                        "95,000 - 125,000", 
                        Arrays.asList("ROS", "C++", "Python")),

                new Job(null, "Data Scientist", "DataWiz", "Boston",
                		"Analyze large datasets to drive decision-making.", "100,000 - 130,000", 
                		Arrays.asList("Python", "TensorFlow", "SQL")),
                
                new Job(null, "DevOps Engineer", "CloudCore", "Seattle",
                		"Manage cloud infrastructure and CI/CD pipelines.", "90,000 - 110,000", 
                		Arrays.asList("AWS", "Docker", "Kubernetes")),
                
                new Job(null, "UI/UX Designer", "PixelWorks", "Austin", 
                		"Design intuitive user interfaces and user experiences.", "70,000 - 90,000", 
                		Arrays.asList("Figma", "Sketch", "Adobe XD")),
                
                new Job(null, "Mobile Developer", "AppNation", "Chicago", 
                		"Develop iOS and Android applications.", "85,000 - 100,000", 
                		Arrays.asList("Flutter", "Dart", "Swift")),
                
                new Job(null, "Machine Learning Engineer", "AIMinds", "Remote", 
                		"Build and optimize machine learning models.", "110,000 - 140,000", 
                		Arrays.asList("Python", "Scikit-learn", "TensorFlow")),
                
                new Job(null, "QA Engineer", "QualitySoft", "Denver", 
                		"Ensure software quality with automated testing tools.", "75,000 - 90,000", 
                		Arrays.asList("Selenium", "JUnit", "Cypress")),
                
                new Job(null, "Project Manager", "ManagePro", "Atlanta", 
                		"Lead software development projects and teams.", "95,000 - 115,000", 
                		Arrays.asList("Agile", "Scrum", "Jira")),
                
                new Job(null, "Security Analyst", "SecureIT", "Los Angeles", 
                		"Monitor systems for security threats.", "90,000 - 110,000", 
                		Arrays.asList("SIEM", "Penetration Testing", "Firewalls")),
                
                new Job(null, "Cloud Architect", "SkyNet", "Remote", 
                		"Design scalable cloud solutions.", "120,000 - 150,000", 
                		Arrays.asList("Azure", "AWS", "GCP")),
                
                new Job(null, "Database Administrator", "DataSafe", "Houston", 
                		"Maintain and optimize database performance.", "80,000 - 100,000", 
                		Arrays.asList("Oracle", "MySQL", "PostgreSQL")),
                
                new Job(null, "Technical Writer", "DocuTech", "Philadelphia", 
                		"Create and maintain technical documentation.", "65,000 - 80,000", 
                		Arrays.asList("Markdown", "Confluence", "Git")),
                
                new Job(null, "Business Analyst", "InsightPro", "Miami", 
                		"Analyze business needs and recommend solutions.", "75,000 - 95,000", 
                		Arrays.asList("SQL", "Excel", "Power BI"))
            		);

            jobRepository.saveAll(jobs);
            System.out.println("20 sample jobs added to the database.");
        }
    }
}
