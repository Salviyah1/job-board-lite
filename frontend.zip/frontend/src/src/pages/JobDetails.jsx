import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getJobDetails } from '../api';
import ApplicationForm from '../components/ApplicationForm';

export default function JobDetails() {
  const { id } = useParams();
  const [job, setJob] = useState(null);

  useEffect(() => {
    getJobDetails(id).then(response => setJob(response.data));
  }, [id]);

  if (!job) {
    return (
      <div className="container text-center mt-4">
        <div className="spinner-border text-primary" role="status" style={{ width: '2rem', height: '2rem' }} />
        <p className="mt-2 fs-6">Loading job details...</p>
      </div>
    );
  }

  return (
    <div className="container my-4 d-flex justify-content-center">
      <div className="w-100" style={{ maxWidth: '800px' }}>
        <div className="rounded-3 shadow bg-white p-4 border-0">

          {/* Header */}
          <div
            className="text-center p-4 mb-4 rounded"
            style={{ background: 'linear-gradient(135deg, #e3f2fd, #bbdefb)' }}
          >
            <h2 className="fw-bold mb-1 text-dark fs-3">{job.title}</h2>
            <h5 className="text-secondary fs-5">{job.company} • {job.location}</h5>
          </div>

          {/* Description */}
          <p className="mb-4 fs-5 text-muted">{job.description}</p>

          {/* Salary and Skills */}
          <div className="mb-4">
            <h6 className="fw-bold text-dark mb-2 fs-5">Salary Range</h6>
            <p className="fs-4 text-success">{job.salaryRange || 'Not specified'}</p>

            <h6 className="fw-bold text-dark mt-4 mb-2 fs-5">Required Skills</h6>
            {job.requiredSkills && job.requiredSkills.length > 0 ? (
              <div className="d-flex flex-wrap gap-2">
                {job.requiredSkills.map((skill, index) => (
                  <span key={index} className="badge bg-primary-subtle text-primary px-3 py-2 rounded-pill fs-6">
                    {skill}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-muted fs-5">No specific skills listed</p>
            )}
          </div>

          <hr className="my-4" />

          {/* Application Form */}
          <h4 className="mb-3 fs-4">📩 Apply Now</h4>
          <ApplicationForm jobId={job.id} />
        </div>
      </div>
    </div>
  );
}