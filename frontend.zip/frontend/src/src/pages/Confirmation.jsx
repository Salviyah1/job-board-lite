import { useNavigate } from 'react-router-dom';

export default function Confirmation() {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate('/'); 
  };

  return (
    <div className="container mt-5 d-flex justify-content-center">
      <div className="card shadow-lg border-0 rounded-4 text-center p-5" style={{ maxWidth: '500px' }}>
        <div className="mb-4">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="72"
            height="72"
            fill="currentColor"
            className="bi bi-check-circle-fill text-success"
            viewBox="0 0 16 16"
          >
            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-.05z" />
          </svg>
        </div>
        <h3 className="mb-3 fw-bold text-success">Application Submitted!</h3>
        <p className="mb-4 fs-5 text-muted">Thank you for your interest. Your application has been received and will be reviewed by our team. We will get back to you as soon as possible.</p>
        <button className="btn btn-outline-primary rounded-pill px-4" onClick={handleGoBack}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="18"
            height="18"
            fill="currentColor"
            className="bi bi-arrow-left me-2"
            viewBox="0 0 16 16"
          >
            <path fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5a.5.5 0 0 0 .5-.5z" />
          </svg>
          Go Back
        </button>
      </div>
    </div>
  );
}