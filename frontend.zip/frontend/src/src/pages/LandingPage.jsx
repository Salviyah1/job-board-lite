import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Add this
import { getAllJobs, searchJobsByRole } from '../api';
import JobList from '../components/JobList';
import JobSearchForm from '../components/JobSearchForm';

export default function LandingPage() {
  const [jobs, setJobs] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    getAllJobs().then(response => setJobs(response.data));
  }, []);

  const handleSearch = (role) => {
    if (!role.trim()) {
      getAllJobs().then(response => setJobs(response.data));
    } else {
      searchJobsByRole(role).then(response => setJobs(response.data));
    }
  };
  

  return (
    <div className="container mt-4">
      <div
        className="text-center p-5 mb-5 rounded shadow"
        style={{ background: 'linear-gradient(135deg, #f8f9fa, #e9ecef)' }}
      >
        <h1 className="display-4 fw-bold text-dark">
          Welcome to <span className="text-primary">Job Board Lite</span>
        </h1>
        <p className="lead text-secondary">Discover top tech jobs tailored just for you</p>
      </div>
      <JobSearchForm onSearch={handleSearch} />
      <JobList jobs={jobs} />
    </div>
  );
}
