import axios from 'axios';

const API_BASE_URL = 'http://localhost:8081/api';

export const getAllJobs = () => axios.get(`${API_BASE_URL}/jobs`);
export const searchJobsByRole = (role) => axios.get(`${API_BASE_URL}/jobs/search?role=${role}`);
export const getJobDetails = (id) => axios.get(`${API_BASE_URL}/jobs/${id}`);
export const submitApplication = (application) => axios.post(`${API_BASE_URL}/applications`, application);
