import JobCard from './JobCard';

export default function JobList({ jobs }) {
  if (jobs.length === 0) {
    return <p>No jobs found.</p>;
  }

  return (
    <div className="row">
      {jobs.map(job => (
        <div key={job.id} className="col-md-4">
          <JobCard job={job} />
        </div>
      ))}
    </div>
  );
}
