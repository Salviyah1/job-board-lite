import { useState } from 'react';
import { submitApplication } from '../api';
import { useNavigate } from 'react-router-dom';

export default function ApplicationForm({ jobId }) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    submitApplication({ fullName, email, jobId })
      .then(() => navigate('/confirmation'));
  };

  return (
    <form onSubmit={handleSubmit}>
      
      <div className="mb-2">
        <input className="form-control" type="text" placeholder="Full Name" value={fullName} onChange={e => setFullName(e.target.value)} required />
      </div>
      <div className="mb-2">
        <input className="form-control" type="email" placeholder="Email Address" value={email} onChange={e => setEmail(e.target.value)} required />
      </div>
      <button className="btn btn-success" type="submit">Submit Application</button>
    </form>
  );
}
