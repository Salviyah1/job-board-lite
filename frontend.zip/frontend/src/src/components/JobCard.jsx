import { Link } from 'react-router-dom';

export default function JobCard({ job }) {
  return (
    <div
      className="mb-4 p-4 rounded shadow text-center mx-auto"
      style={{
        maxWidth: '650px',
        background: 'linear-gradient(135deg, #f8f9fa, #e9ecef)', // Gradient light gray
        border: '1px solid #dee2e6',
      }}
    >
      <h5 className="fw-bold">{job.title}</h5>
      <h6 className="text-muted">{job.company}</h6>
      <p className="text-muted mb-1">{job.location}</p>
      <p>{job.description.slice(0, 100)}...</p>
      <Link to={`/jobs/${job.id}`} className="btn btn-outline-primary mt-2">
        View Details
      </Link>
    </div>
  );
}
