import { useState } from 'react';

export default function JobSearchForm({ onSearch }) {
  const [role, setRole] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch(role);
  };

  return (
    <form onSubmit={handleSubmit} className="mb-4">
      <div className="input-group">
        <input
          type="text"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          placeholder="Search by job role"
          className="form-control"
        />
        <button type="submit" className="btn btn-primary">
          Search
        </button>
      </div>
    </form>
  );
}
